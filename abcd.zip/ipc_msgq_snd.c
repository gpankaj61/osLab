#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>

struct msg {
	long mtype;
	char str[200];
	};
	
int main()
{
	key_t key;
	int msqid;
	struct msg d;
	printf("\n::::::: SERVER Process : Writing to Queue ::::::::::\n");
	key = ftok("ipc_pipes.c",'A');
	msqid = msgget(key,0666|IPC_CREAT);
	
	while(1)
	{
		int x;
		printf("\n 1. Write to message queue.\n 2. Exit.\n");
		scanf("%d",&x);
		getchar();
		switch(x)
		{
			case 1: printf("\n Enter the data : \n");
					gets(d.str);
					d.mtype=1;
					msgsnd(msqid,&d,sizeof d,0);
					break;
			case 2: msgctl(msqid,IPC_RMID,NULL);
					exit(0);
		}
	}
	
	return 0;
}
