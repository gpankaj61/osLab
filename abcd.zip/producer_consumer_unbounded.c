#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<semaphore.h>
#include<sys/types.h>
#include<sys/wait.h>


#define PATH1 "/s"
#define PATH2 "/f"
#define PATH3 "/e"

int buff[100000];
int n=10;
int i=0,j=0;
void * producer(void *);
void * consumer(void *);

sem_t *s, *f;

int main()
{
	pthread_t cons,prod;
	
	//sem_unlink(PATH1);
	//sem_unlink(PATH2);
	
	s = sem_open(PATH1,O_CREAT);
	f = sem_open(PATH2,O_CREAT);

	sem_init ( s ,0, 1);
	sem_init ( f ,0, 0);
	
	pthread_create(&cons,NULL,&consumer,NULL);
	pthread_create(&prod,NULL,&producer,NULL);
	
	pthread_join(cons,NULL);
	pthread_join(prod,NULL);
	
	return 0;
}

void * producer(void * x)
{
	while(1)
	{

		sem_wait(s);	
	
		buff[i]=random()%10;
		printf("\n producer >> produced : %d : number of elements in buff : %d : \n",buff[i],i+1);
		i++;
		
		sem_post(f);
		sem_post(s);
		sleep(0.50);
	}
}


void * consumer(void * x)
{
	while(1)
	{
		if(i<=0) printf("\n consumer >> Waiting ... Buffer Empty!!.\n");

		sem_wait(f);
		sem_wait(s);	
		
		printf("\n consumer >> consumed : %d : number of elements in buff : %d : \n",buff[0],i-1);
		i--;
		
		for(j=1; j <= i ; j++) buff[j-1]=buff[j];
		
		sem_post(s);
		sleep(0.50);
	}
}
