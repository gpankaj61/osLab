#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<semaphore.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<unistd.h>
#define PATH "sem"
int main()
{
	sem_t * s,*p;		//semaphore variable declaration
	pid_t pid;
	sem_unlink("xyz");
	sem_unlink(PATH);
	s = sem_open(PATH,O_CREAT);
	sem_init(s,1,1);
	p = sem_open("xyz",O_CREAT);
	sem_init(p,1,0);
	sem_wait(s);
	//Parent locks the semaphore
	
	if(( pid=fork() ) < 0)
	{
		printf("\n Error in fork.\n");
		exit(1);
	}
	else if(pid==0)
	{
		//Child process
		
		//sleep(1);			//sleep for testing
		
		sem_wait(s);
		printf("\n ==== > This is the first child process...\n");
		sem_post(s);
		sem_post(p);
	}
	else
	{
		// Parent process
		if(fork()==0)
		{
			sem_wait(p);
			printf("\n ==== > This is the  second child process...\n");				
			
		}
		else
		{
			sleep(1);			//sleep for testing
		
			printf("\n ==== > This the parent process... \n");
			sem_post(s);
		}
	}
	sleep(2);
	sem_unlink(PATH);
	return 0;
}
