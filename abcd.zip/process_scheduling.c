#include<stdio.h>
#include<stdlib.h>
#define N 10
#define MAX_TIME 100000

int pid[N];
int n;
int arrTime[N];
int burstTime[N];
int compTime[N];
int TrnArndTime[N];
int waitTime[N];
int timediagram[MAX_TIME];

void FCFS();
void SJF();
void SRTF();
void printTable();
void printTchart();

void setit()
{
	int i=0;
	for(i=0 ; i<MAX_TIME ; i++) timediagram[i]=-1;
}

int main()
{	
	printf("\n ::::::: Process Scheduling ::::::: \n ");
	printf("\n Enter the number of processes (less than %d) : ",N);
	scanf("%d",&n);
	
	
	
	printf("\n Enter the Arrival Time and Burst Time of these processes :\n");
	
	int i=0;
	for(i=0;i<n;i++)
	{
		printf("\n Enter the Arrival time and Burst time of process P[%d] : ",i);
		scanf("%d %d",&arrTime[i],&burstTime[i]);
		pid[i]=i;
	}
	
	while(1)
	{
		setit();
		int ch;
		printf("Enter the Scheduling Algorithm : \n::::::::::::::::\n 1.FCFS \n 2.SJF \n 3.SRTF \n 4.exit\n  Enter the choice : ");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:	printf("\n :::: FCFS ::::\n");
					FCFS();
					printTchart();
					break;
			case 2: printf("\n :::: SJF ::::\n");
					SJF();
					printTchart();
					break;
			case 3: printf("\n :::: SRTF ::::\n");
					SRTF();
					printTchart();
					break;
			case 4: return 0;
		}
	
	}
}

/*---------------FCFS-------------------------*/	
	
void FCFS()
{
	int time = 0;
	int is[N]={0};
	int i,j,k,min;
	
	for(i=0;i<n;i++)
	{
		j=0;
		while(j<n && is[j]==1) j++;
		if(j==n) { time++; i--; continue; }
		min=j;
		for(j=0;j<n;j++)
		{
			if(is[j]!=1 && arrTime[min] > arrTime[j])
			{
				min=j;
			}
		}
		is[min]=1;
		
		for(k = j = time ; k<(j+burstTime[min]) ; k++)
				timediagram[k]=min;
		
		time = ( time > arrTime[min] ? time : arrTime[min] ) + burstTime[min];
		compTime[min]=time;
		TrnArndTime[min] = compTime[min] - arrTime[min];
		waitTime[min] = TrnArndTime[min] - burstTime[min]; 
	}
	printTable();
}
/*----------------------- SJF ----------------------------*/
void SJF()
{
	int time = 0;
	int is[N]={0};
	int i,j,k,min;
	
	for(i=0;i<n;i++)
	{
		j=0;
		min=-1;
		while(j<n && arrTime[j]<=time && is[j]==1) j++;
		if(j==n) { time++; i--; continue; }
		min=j;
		for(j=0;j<n;j++)
		{
			if(is[j]!=1 && arrTime[j]<=time && burstTime[min] > burstTime[j])
			{
				min=j;
			}
		}
		is[min]=1;
		
		for(k=j= time ; k<(j+burstTime[min]) ; k++)
			timediagram[k]=min;
		
		time = ( time > arrTime[min] ? time : arrTime[min] ) + burstTime[min];
		compTime[min]=time;
		TrnArndTime[min] = compTime[min] - arrTime[min];
		waitTime[min] = TrnArndTime[min] - burstTime[min]; 
	}
	printTable();
}

/*--------------------SRTF-----------------------------------*/

void SRTF()
{

	int time=0;
	int maxtime=0;
	int i,j,min;
	
	int isCompleted[N]={0},comp=0;
	int remainTime[N]={0};
	
	for(i=0;i<n;i++) remainTime[i] = burstTime[i];
	
	while(1)
	{
		if(comp==n) break;
        
		min=-1;
       
        j=0;
		while(j<n && arrTime[j]<=time && isCompleted[j]) j++;
		if(j==n) { time++ ; continue; }
        
		min=j;
		
		
		
		for(j=0;j<n;j++)
		{
			if(isCompleted[j] != 1 && arrTime[j]<=time && remainTime[min] > remainTime[j])
			{
				min=j;
			}
		}
		
		remainTime[min]--;
		
		timediagram[time]=min;
		time++;
	
		
			if(remainTime[min]==0)
			{
				isCompleted[min]=1;
				comp++;
				compTime[min]=time;
				TrnArndTime[min] = compTime[min] - arrTime[min];
				waitTime[min] = TrnArndTime[min] - burstTime[min];
			}
		
		
		
	}
    printTable();
	
}
/*--------------PRINT TABLE--------------------------------*/

void printTable()
{
	printf("\nProcess\tArr Time\tburst Time\twait Time\tTurn Around Time\tcompletion Time\n ");
	int i,avgwait=0,avgtat=0;
	for(i=0;i<n;i++)
	{
		printf("\n p[%d] \t\t %d \t\t %d \t\t %d \t\t %d \t\t %d \n",i,arrTime[i],burstTime[i],waitTime[i],TrnArndTime[i],compTime[i]);
		avgwait+=waitTime[i];
		avgtat+=TrnArndTime[i];
	}
	printf("\n Average Turn Around Time = %f\n",(float)avgtat/n);
	printf("\n Average Waiting Time = %f\n",(float)avgwait/n);	

}	
/*--------------------CHART----------------------------*/
void printTchart()
{
	int i=0;
	printf("::::Gantt Chart:::::\nTimeFrame\tProcess\n");
	for(i=0; timediagram[i]!=-1 ; i++)
	{
		printf("%d->%d \t=\t %d\n",i,i+1,timediagram[i]);	
	}
}
