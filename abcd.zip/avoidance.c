#include<stdio.h>
#include<stdlib.h>

//void getMat(int a[10][10], int m, int n);

int main()
{

	int p,r;
	
	printf("\n\t::::DEADLOCK AVOIDANCE:::::\n");
	printf("\n Enter the number of processess : ");
	scanf("%d",&p);
	
	printf("\n Enter the number of resources : ");
	scanf("%d",&r);
	
	int alloc[p][r], req[p][r], avail[r], completed[20]={0}, i, j, k;
	
	printf("\n Enter the allocated matrix : \n");
	//getMat(alloc,p,r);
	for(i=0;i<p;i++)
	{
		printf("P[%d] ",i+1);
		for(j=0;j<r;j++)
		{
			scanf("%d",&alloc[i][j]);
		}
	}
	
	printf("\n Enter the request matrix : \n");
	//getMat(req,p,r);
	for(i=0;i<p;i++)
	{
		printf("P[%d] ",i+1);
		for(j=0;j<r;j++)
		{
			scanf("%d",&req[i][j]);
		}
	}
	
	printf("\n Enter the available vector : ");
	for(i=0;i<r;i++) scanf("%d",&avail[i]);
	
	// Deadlock Avoidance Algorithm : Banker's Algorithm
	printf("\n The safe sequence is : ");
	for(i=0; i<p; i++)
	{
		for(j=0; j<p; j++)
		{
			if(completed[j]) continue;
			int safe = 1;
			for(k=0; k<r ;k++) {
				if(req[j][k] > avail[k]) safe = 0;
				//printf("%d.%d,",req[j][k],avail[k]);
			}
			//printf(":%d:%d:%d\n",i,j,safe);
			if(safe)
			{
				completed[j] = 1;
				printf(" -> P[%d]",j+1);
				
				for( k=0; k<r ; k++) avail[k] += alloc[j][k];
				
				break;	
			}
		}
	}
	int chk = 0;	
	for( k=0 ; k<p ; k++)
	{
		if(!completed[k]) chk = 1;
	}
	
	if(chk) printf("\n DEADLOCK occured\n");
	printf("\n");
	return 0;
}

/*void getMat(int a[10][10], int m,int n)
{
	int i,j;
	for(i=0;i<m;i++)
	{
		printf("P[%d]",i+1);
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
}*/
