#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>

struct msg {
	long mtype;
	char str[200];
	};
	
int main()
{
	key_t key;
	int msqid;
	struct msg d;
	printf("\n::::::: CLIENT Process : Reading from Queue ::::::::::\n");
	printf("\nThe recieved messages are :: \n");
	key = ftok("ipc_pipes.c",'A');
	msqid = msgget(key,0666);
	while(1)
	{
		if(msgrcv(msqid,&d,sizeof d,0,0)<0) break;
		printf("%s\n",d.str);
	}
	
	return 0;
}
