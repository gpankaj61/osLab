#include<stdio.h>
#include<stdlib.h>

#define N 10
#define MAX_TIME 100000

int pid[N];
int n;
int arrTime[N];
int burstTime[N];
int compTime[N];
int TrnArndTime[N];
int priority[N];

int waitTime[N];
int timediagram[MAX_TIME];

int readyQueue[N];
int end=0;



void priority_p();
void printTable();
void printTchart();



void setit()
{
	int i=0;
	for(i=0 ; i<MAX_TIME ; i++) timediagram[i]=-1;
}

int main()
{	
	printf("\n ::::::: Process Scheduling ::::::: \n ");
	printf("\n Enter the number of processes (less than %d) : ",N);
	scanf("%d",&n);
	
	setit();
	
	printf("\n Enter the Arrival Time and Burst Time of these processes :\n");
	
	int i=0;
	for(i=0;i<n;i++)
	{
		printf("\n Enter the Arrival time, Burst time and Priority of process P[%d] : ",i+1);
		scanf("%d %d %d",&arrTime[i],&burstTime[i],&priority[i]);
		pid[i]=i+1;
	}
	
	printf("\n::::Priority Scheduling : Preemptive:::::::\n");
	priority_p();
	
	return 0;
}

void priority_p()
{
	int time=0;
	int maxtime=0;
	int i,j,min;
	
	int isCompleted[N]={0},comp=0;
	int remainTime[N]={0};
	
	for(i=0;i<n;i++) remainTime[i] = burstTime[i];
	
	while(1)
	{
		if(comp==n) break;
        
		min=-1;
       
        j=0;
		while(j<n && arrTime[j]<=time && isCompleted[j]) j++;
		if(j==n) {timediagram[time]=0; time++ ; continue; }
        
		min=j;
		
		
		
		for(j=0;j<n;j++)
		{
			if(isCompleted[j] != 1 && arrTime[j]<=time && priority[min] < priority[j])
			{
				min=j;
			}
		}
		
		remainTime[min]--;
		
		timediagram[time]=min+1;
		time++;
	
		
			if(remainTime[min]==0)
			{
				isCompleted[min]=1;
				comp++;
				compTime[min]=time;
				TrnArndTime[min] = compTime[min] - arrTime[min];
				waitTime[min] = TrnArndTime[min] - burstTime[min];
			}
		
		
		
	}
    printTable();
    printTchart();
}


/*--------------PRINT TABLE--------------------------------*/

void printTable()
{
	printf("\nProcess\t   Arr Time\tburst Time\t   Priority\t   wait Time\tTurn Around Time\tcompletion Time\n ");
	int i,avgwait=0,avgtat=0;
	for(i=0;i<n;i++)
	{
		printf("\n p[%d] \t\t %d \t\t %d \t\t %d \t\t %d \t\t %d \t\t %d \n",i+1,arrTime[i],burstTime[i],priority[i],waitTime[i],TrnArndTime[i],compTime[i]);
		avgwait+=waitTime[i];
		avgtat+=TrnArndTime[i];
	}
	printf("\n Average Turn Around Time = %f\n",(float)avgtat/n);
	printf("\n Average Waiting Time = %f\n",(float)avgwait/n);	

}	
/*--------------------CHART----------------------------*/
void printTchart()
{
	int i=0;
	printf("\n::::Gantt Chart:::::\nTimeFrame Process\n");
	for(i=0; timediagram[i]!=-1 ; i++)
	{
		printf("%d->%d \t= P[%d]\n",i,i+1,timediagram[i]);	
	}
}
