#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<unistd.h>
#include<errno.h>

int main()
{
	pid_t pid;
	int fd[2];
	
	pipe(fd);
	
	if((pid=fork())<0)
	{
		perror("Cannot Fork\n");
		exit(0);
	}
	else if ( pid==0)
	{
			// Child process
			printf("\nThis CHILD Process : I am Writing in pipe\n");
			char str[100];
		close(fd[0]);
		printf("\n Enter the message to be send to the Parent : \n");
		gets(str);
		write(fd[1],str,sizeof(str));
		//sleep(2);
	}
	else
	{
			// Parent Process
		char str[100];
		close(fd[1]);
		printf("\nThis PARENT Process : I am Reading from pipe\n");
		//sleep(2);
		read(fd[0],str,100);
		printf("\n The message sent by child is :: \n");
		printf("%s\n",str);
		wait(NULL);
	}
	
	return 0;
}
