#include<stdio.h>
#include<string.h>
int main(){
	int pos;
	int opt;
	printf("Enter 1.FIFO\t 2.LRU \t 3.Optimal\n");
	scanf("%d",&opt);
	int no_of_frames;
	printf("Enter no of frames\n");
	scanf("%d",&no_of_frames);
	int string[100];
	int n;
	printf("Enter page string size\n");
	scanf("%d",&n);
	printf("Enter string:");
	int i;
	for(i=0;i<n;i++){
		scanf("%d",&string[i]);
	}
	int page_faults=0;
	i=0;
	int frames[100];
	for(i=0;i<no_of_frames;i++){
		frames[i]=string[i];
		page_faults++;	
	}	
	int m;
   	printf("\nUpdated pade table::::");
   	for(m=0;m<no_of_frames;m++)
   		printf("%d\t",frames[m]);
   	printf("\n");
	while(i<n){
		//print the page table
		pos=-1;
		int flag=0;
		int j;
		for(j=0;j<no_of_frames;j++){
			if(frames[j]==string[i]){
				flag=1;
				pos=j;
			}
		}
		if(opt==1){
			if(flag==0){
				//Fifo
				int k;
				for(k=0;k<no_of_frames-1;k++){
					frames[k]=frames[k+1];
				}
				frames[no_of_frames-1]=string[i];	
				page_faults++;
				printf("\n::::::Page fault for  page:%d\n",string[i]);
			}
		}
		else if(opt==2){
			//LRU
			if(flag==0){
				int k;
				for(k=0;k<no_of_frames-1;k++){
					frames[k]=frames[k+1];
				}
				frames[no_of_frames-1]=string[i];	
				page_faults++;
				printf("\n::::::Page fault for  page:%d\n",string[i]);
	
			}
			else{
				if(pos!=-1){
					int k;
					for(k=pos;k<no_of_frames-1;k++){
						frames[k]=frames[k+1];
					}
					frames[no_of_frames-1]=string[i];	
				}
			}	
		}
		else if(opt==3){
			if(flag==0){
				//Optimal
				int dist[no_of_frames];
				int k;
				//initialize the distances
				for(k=0;k<no_of_frames;k++){
					dist[k]=9999;
				}
				int l;
				for(l=0;l<no_of_frames;l++){
					for(k=i;k<n;k++){
						if(frames[l]==string[k]){
							dist[l]=k-i;	
							break;	
						}
					}
				}
				//find page with maximum distance
				int max=0;
				printf("\nPrinting distance table\n");
				printf("dist=%d  for frame=%d\n",dist[0],frames[0]);
				for(k=1;k<no_of_frames;k++){
					printf("dist=%d  for frame=%d\n",dist[k],frames[k]);
					if(dist[max]<dist[k]){
						//store its index
						max=k;
					}
				}
				printf("\n");
				//remove the page with index k
				frames[max]=string[i];
				page_faults++;
				printf("\n::::::Page fault for  page:%d\n",string[i]);
			}	
		}
		int m;
   		printf("\nUpdated pade table::::");
   		for(m=0;m<no_of_frames;m++)
   			printf("%d\t",frames[m]);
   		printf("\n");
		i++;
	}	
	printf("\n\nNo of page faults::::%d\n",page_faults);
	return 0;
}
