#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#define PATH "socket"

int main(void)
{
    int s, t, len;
    struct sockaddr_un r;
    char str[100],xstr[100];

    if ((s = socket(AF_UNIX, SOCK_STREAM, 0)) < 0) {
        perror("socket not working\n");
        exit(1);
    }

    printf("Trying to connect...\n");

    r.sun_family = AF_UNIX;
    strcpy(r.sun_path,PATH);
    len = strlen(r.sun_path) + sizeof(r.sun_family);


    if (connect(s, (struct sockaddr *)&r, len) == -1) {
        perror("unable to connect");
        exit(1);
    }

    printf("Connected.\n");

    printf("Enter a message for the server : \n>>");
    scanf(" %[^\n]s",str);

    send(s,str,strlen(str),0);
    recv(s, str, 100, 0);
            
    printf("echo> %s\n", str);
    
    close(s);

    return 0;
}
