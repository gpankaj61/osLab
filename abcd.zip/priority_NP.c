#include<stdio.h>
#include<stdlib.h>

#define N 10
#define MAX_TIME 100000

int pid[N];
int n;
int arrTime[N];
int burstTime[N];
int compTime[N];
int TrnArndTime[N];
int waitTime[N];
int timediagram[MAX_TIME];
int priority[N];

void priority_np();
void printTable();
void printTchart();

void setit()
{
	int i=0;
	for(i=0 ; i<MAX_TIME ; i++) timediagram[i]=-1;
}

int main()
{	
	printf("\n ::::::: Process Scheduling ::::::: \n ");
	printf("\n Enter the number of processes (less than %d) : ",N);
	scanf("%d",&n);
	
	setit();
	
	printf("\n Enter the Arrival Time and Burst Time of these processes :\n");
	
	int i=0;
	for(i=0;i<n;i++)
	{
		printf("\n Enter the Arrival time, Burst time and Priority of Process P[%d] : ",i+1);
		scanf("%d %d %d",&arrTime[i],&burstTime[i],&priority[i]);
		pid[i]=i+1;
	}
	printf("\n:::::PRIORITY SCHEDULING : Non Preemptive:::::\n");
	priority_np();
	
	return 0;
}

void priority_np()
{
	int time = 0;
	int is[N]={0};
	int i,j,k,min;
	
	for(i=0;i<n;i++)
	{
		j=0;
		min=-1;
		while(j<n && arrTime[j]<=time && is[j]==1) j++;
		if(j==n) { timediagram[time]=0; time++; i--; continue; }
		min=j;
		for(j=0;j<n;j++)
		{
			if(is[j]!=1 && arrTime[j]<=time && priority[j]>=priority[min])
			{
				min=j;
			}
		}
		
		is[min]=1;
		
		for(k=j= time ; k<(j+burstTime[min]) ; k++)
			timediagram[k]=min+1;
		
		time = ( time > arrTime[min] ? time : arrTime[min] ) + burstTime[min];
		compTime[min]=time;
		TrnArndTime[min] = compTime[min] - arrTime[min];
		waitTime[min] = TrnArndTime[min] - burstTime[min]; 
	}
	printTable();
	printTchart();
}


/*--------------PRINT TABLE--------------------------------*/

void printTable()
{
	printf("\nProcess\t    Arr Time\tburst Time\t  priority\t  wait Time\tTurn Around Time\tcompletion Time\n ");
	int i,avgwait=0,avgtat=0;
	for(i=0;i<n;i++)
	{
		printf("\n p[%d] \t\t %d \t\t %d \t\t %d \t\t %d \t\t %d \t\t %d \n",i+1,arrTime[i],burstTime[i],priority[i],waitTime[i],TrnArndTime[i],compTime[i]);
		avgwait+=waitTime[i];
		avgtat+=TrnArndTime[i];
	}
	printf("\n Average Turn Around Time = %f\n",(float)avgtat/n);
	printf("\n Average Waiting Time = %f\n",(float)avgwait/n);	

}	
/*--------------------CHART----------------------------*/
void printTchart()
{
	int i=0;
	printf("\n::::Gantt Chart:::::\nTimeFrame  Process\n");
	for(i=0; timediagram[i]!=-1 ; i++)
	{
		printf("%d->%d \t= P[%d]\n",i,i+1,timediagram[i]);	
	}
}
