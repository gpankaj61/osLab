#include<stdio.h>
#include<math.h>
#include<limits.h>
int temp;
int cmp(const void *l,const void *r){
	int *ll=(int *)l;
	int *rr=(int *)r;
	return (*ll)>(*rr);
}
int cp(const void *l,const void *r){
	int *ll=(int *)l;
	int *rr=(int *)r;
	return fabs(temp-*ll)>fabs(temp-*rr);
}
int main(){
	int n,i,len,start;
	printf("Enter Number of Elements:\n");
	scanf("%d",&n);
	int arr[n];
	printf("Enter Elements\n");
	for(i=0;i<n;i++)
		scanf("%d",&arr[i]);
	printf("Enter Length of Cyclinder\n");
	scanf("%d",&len);
	printf("Enter Header\n");
	scanf("%d",&start);
	temp=start;
	
	printf("::::::::::::::FCFS::::::::::::::\n");
	int ans=0;
	for(i=0;i<n;i++)
	{
		ans+=fabs(start-arr[i]);
		start=arr[i];
	}
	printf("Total SEEK TIME (FCFS): %d\n",ans);


	printf(":::::::::SCAN:::::::::::\n");
	ans=fabs(len-1-temp);
	int minn=100000;
	for(i=0;i<n;i++)
		if(minn>arr[i])
			minn=arr[i];
	ans+=fabs(len-1-minn);
	printf("Total SEEK TIME (SCAN): %d\n",ans);

	
	printf("::::::::::::::CSCAN:::::::::::::::\n");
	ans=fabs(len-1-temp);
	qsort(arr,n,sizeof(arr[0]),cmp);
	for(i=0;i<n;i++)
		if(arr[i]>=temp)
			break;
	if(i!=-1)		
		ans+=arr[i-1];
	printf("Total SEEK TIME (CSCAN): %d\n",ans);
		

	printf("::::::::::::::LOOK SCAN:::::::::::::::\n");
	ans=fabs(arr[n-1]-temp)+fabs(arr[n-1]-arr[0]);
	printf("Total SEEK TIME (LOOK SCAN): %d\ns",ans);				
		

	printf(":::::::::::::::::SSTF:::::::::::::::::\n");
	int j=0;
	ans=0;		
	start=temp;	
	for(i=0;i<n;i++){		
		qsort(arr,n,sizeof(arr[0]),cp);
		ans+=fabs(temp-arr[0]);
		temp=arr[0];
		arr[0]=INT_MAX;	
	}
	printf("Total SEEK TIME (SSTF): %d\n",ans);							

return 0;
}
