#include<stdio.h>
#include<string.h>
struct mem_block{
	int sz;
	int sz_allocated;
	int flag;
};
int main(){
	int size,nblocks,choice;
	printf("Enter memory size\n");
	scanf("%d",&size);
	printf("Enter no of blocks\n");
	scanf("%d",&nblocks);
	struct mem_block mem[nblocks];
	printf("Enter size of all blocks in string form\n");
	int i;
	for(i=0;i<nblocks;i++){
		int temp;
		scanf("%d",&temp);
		mem[i].sz=temp;
		mem[i].flag=0;
		mem[i].sz_allocated=0;
	}
	printf("Enter 1.Best fit \t 2.Worst Fit \t 3.First Fit\n");
	scanf("%d",&choice);
	int n;
	printf("Enter no of allocations needed\n");
	scanf("%d",&n);
	int alloc[n];
	printf("Enter size of the blocks to be allocated in string form\n");
	for(i=0;i<n;i++){
		scanf("%d",&alloc[i]);
	}
	if(choice==1){
		//Best Fit
		printf("Best Fit Algo::::::::\n");
		i=0;
		while(i<n){
			int dist=9999;
			int j,pos;
			for(j=0;j<nblocks;j++){
				if(mem[j].flag==0){
					int temp=mem[j].sz-alloc[i];
					if(temp>=0 && temp<dist){
						dist=temp;
						pos=j;	
					}
				}
			}
			//allocate this block
			if(mem[pos].flag==0){
				mem[pos].sz_allocated=alloc[i];
				mem[pos].flag=1;
			}
			i++;
		}
	}
	else if(choice==2){
		//Worst Fit
		printf("Worst Fit Algo::::::::\n");
		i=0;
		while(i<n){
			int dist=0;
			int j,pos=0;
			for(j=0;j<nblocks;j++){
				if(mem[j].flag==0){
					int temp=mem[j].sz-alloc[i];
					if(temp>=0 && temp>=dist){
						dist=temp;
						pos=j;
						//printf("\n\nCame here for %d\n  and pos=%d",alloc[i],pos);	
					}
				}
			}
			//allocate this block
			//printf("\npos=%d is allocated \n",pos);
			if(mem[pos].flag==0){
				mem[pos].sz_allocated=alloc[i];
				mem[pos].flag=1;
			}
			i++;
		}

	}
	else if(choice==3){
		//First Fit
		printf("First Fit Algo::::::::\n");
		i=0;
		while(i<n){
			int j,pos;
			for(j=0;j<nblocks;j++){
				if(mem[j].flag==0){
					pos=j;	
					break;
				}		
			}
			//allocate this block
			if(mem[pos].flag==0 && mem[pos].sz>=alloc[i]){
				mem[pos].sz_allocated=alloc[i];
				mem[pos].flag=1;
			}
			i++;
		}
	}
	
 	printf("Printing allocations::::\n");
	int int_frag=0,ext_frag=0;
	for(i=0;i<nblocks;i++){
		printf("Total size=%d\t Allocated Size=%d\n",mem[i].sz,mem[i].sz_allocated);
		if(mem[i].flag==1)
			int_frag+=mem[i].sz-mem[i].sz_allocated;
		else
			ext_frag+=mem[i].sz;
	}
	printf("External Fragmentation ::%d \t Internal Fragmentation::%d\n",ext_frag,int_frag);
	return 0;
}
