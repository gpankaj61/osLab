#include<stdio.h>
#include<stdlib.h>

#define N 10
#define MAX_TIME 100000
#define SZ 100

int pid[N];
int n;
int arrTime[N];
int burstTime[N];
int compTime[N];
int TrnArndTime[N];
int waitTime[N];

int quanta=1;

int timediagram[MAX_TIME];

int readyQueue[N]={0};
int end=0;

void roundRobin();
void printTable();
void printTchart();

/*--------Queue Operation-------------------*/
void push(int pid)
{
	readyQueue[end]=pid;
	end++;
}
int isempty()
{
	if(end==0) return 1;
	return 0;
}
int pop()
{
	int a = readyQueue[0];
	int i;
	for(i=0;i<end-1;i++) readyQueue[i]=readyQueue[i+1];
	end--;
	return a;
}
/*-------------------------------------------*/

void setit()
{
	int i=0;
	for(i=0 ; i<MAX_TIME ; i++) timediagram[i]=-1;
}

int main()
{	
	printf("\n ::::::: Process Scheduling ::::::: \n ");
	printf("\n Enter the number of processes (less than %d) : ",N);
	scanf("%d",&n);
	
	setit();
	
	printf("\n Enter the Arrival Time and Burst Time of these processes :\n");
	
	int i=0;
	for(i=0;i<n;i++)
	{
		printf("\n Enter the Arrival time and Burst time of process P[%d] : ",i+1);
		scanf("%d %d",&arrTime[i],&burstTime[i]);
		pid[i]=i+1;
	}
	
	printf("\nEnter the Time quanta for algorithm : \n");
	scanf("%d",&quanta);
	
	
	printf("\n:::ROUND ROBIN::::\n");
	roundRobin();
	
	return 0;
}


void roundRobin()
{
	
	int time=0;

	int i,j,min,k=0;
	int Q[SZ]={0};
	int isCompleted[N]={0},comp=0;
	int remainTime[N]={0},ispushed[N]={0};
	
	for(i=0;i<n;i++) remainTime[i] = burstTime[i];
	
	while(1)
	{
		if(comp==n) break;
        if(time > 50) break;
        for(i=0;i<n;i++)
        {
        	if(arrTime[i]==time && !ispushed[i] ) 
        	{
        		push(i);
        		ispushed[i]=1;
        	}
        }
        
		if(isempty()) 
		{
			timediagram[time]=0;
			time++;
			continue;
		}
        
       /* for(i=0;i<end;i++) printf("%d,%d:",time,readyQueue[i]);
        printf("\n");*/
        
        min=Q[k]=pop();
        k++;
		
		/*for(i=0;i<end;i++) printf("%d,%d:",time,readyQueue[i]);
        printf("x\n");*/
		
		j=quanta;
		//printf("x%dx",min+1);
		while(j--)
		{
			remainTime[min]--;
		
			timediagram[time]=min+1;
			time++;
			for(i=0;i<n;i++)
    	    {
    	    	if(arrTime[i]==time && !ispushed[i] ) 
    	    	{
    	    		push(i);
    	    		ispushed[i]=1;
    	    	}
    	    }
			
			//printf("%d:%d\n",time,min);
		
			if(remainTime[min]==0)
			{
				isCompleted[min]=1;
				comp++;
				compTime[min]=time;
				TrnArndTime[min] = compTime[min] - arrTime[min];
				waitTime[min] = TrnArndTime[min] - burstTime[min];
				break;
			}
		
		}	
		if(remainTime[min] != 0) push(min);
		
	}
    printTable();
    printTchart();
    
    printf("\n:::READY QUEUE::::\n");
    for(i=0;i<k;i++)
    {
    	printf("=> P[%d] ",Q[i]+1);
    }
    printf("\n");

}

/*--------------PRINT TABLE--------------------------------*/

void printTable()
{
	printf("\nProcess\t  Arr Time\tburst Time\t  wait Time\tTurn Around Time\tcompletion Time\n ");
	int i,avgwait=0,avgtat=0;
	for(i=0;i<n;i++)
	{
		printf("\n p[%d] \t\t %d \t\t %d \t\t %d \t\t %d \t\t %d \n",i,arrTime[i],burstTime[i],waitTime[i],TrnArndTime[i],compTime[i]);
		avgwait+=waitTime[i];
		avgtat+=TrnArndTime[i];
	}
	printf("\n Average Turn Around Time = %f\n",(float)avgtat/n);
	printf("\n Average Waiting Time = %f\n",(float)avgwait/n);	

}	
/*--------------------CHART----------------------------*/
void printTchart()
{
	int i=0;
	printf("\n::::Gantt Chart:::::\nTimeFrame Process\n");
	for(i=0; timediagram[i]!=-1 ; i++)
	{
		printf("%d->%d \t= P[%d]\n",i,i+1,timediagram[i]);	
	}
}
